import streamlit as st
from google.cloud import aiplatform
from google.auth import default
import os

# === YOUR PROJECT DETAILS ===
PROJECT_ID = "azundow-rag-assistant"          # your project ID
LOCATION = "global"                           # your agent location
AGENT_DISPLAY_NAME = "azundow-rag-assistant"  # exact agent name

# Page config
st.set_page_config(
    page_title="Azundow Intelligent Document Chatbot",
    page_icon="🤖",
    layout="centered"
)

# Title with your logo
col1, col2 = st.columns([1, 6])
with col1:
    st.image("logo.png", width=100)  # your Falibari logo
with col2:
    st.markdown("<h1 style='margin-top: 25px;'>Azundow Intelligent Document Chatbot</h1>", unsafe_allow_html=True)

st.caption("Germany.Built by Philemon Azundow")

# Initialize Vertex AI
try:
    credentials, _ = default()
    aiplatform.init(project=PROJECT_ID, location=LOCATION, credentials=credentials)
    st.success("Connected to Vertex AI")
except Exception as e:
    st.error(f"Connection error: {e}")
    st.info("Run: gcloud auth application-default login --scopes=https://www.googleapis.com/auth/cloud-platform")
    st.stop()

# Find your agent endpoint
with st.spinner("Finding your agent..."):
    try:
        endpoints = aiplatform.Endpoint.list(
            filter=f"display_name={AGENT_DISPLAY_NAME}"
        )
        if not endpoints:
            st.error(f"Agent '{AGENT_DISPLAY_NAME}' not found. Check the name in Agent Builder.")
            st.stop()
        endpoint = endpoints[0]
    except Exception as e:
        st.error(f"Agent lookup failed: {e}")
        st.stop()

# Session state for chat
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display chat
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Chat input
if prompt := st.chat_input("Ask about your documents..."):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    answer = "Sorry, I couldn't get an answer. Please try again."

    with st.chat_message("assistant"):
        with st.spinner("Searching documents..."):
            try:
                response = endpoint.predict(instances=[{"content": prompt}])
                
                answer = response.predictions[0]["content"]
                citations = response.predictions[0].get("citationMetadata", {}).get("citations", [])
                
                st.markdown(answer)
                
                if citations:
                    st.markdown("**Sources:**")
                    for c in citations:
                        title = c.get("title", "Document")
                        page = c.get("startIndex", "")
                        st.markdown(f"- {title} (page {page})")
                        
            except Exception as e:
                st.error(f"Error: {e}")
                st.markdown(answer)

    st.session_state.messages.append({"role": "assistant", "content": answer})

st.markdown("---")
st.caption("Azundow Intelligent Document Chatbot • Vertex AI RAG • Professional")